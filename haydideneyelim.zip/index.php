<?php session_start();?>

<!DOCTYPE html>
<html>

<?php
include 'pageHeader.php'
?>

<body>
<div  id="mainWrapper">
 
     <div id="mainContent">
        <table border="0" cellspacing="0" cellpadding="0"
              id = "tableX"
               >
            <tr>
                <td width = "50%" valign="top" >
                <h1 id="homeBanner"> 
                    Bölümümüze hoş geldiniz <br>
                    İnanilmaz bir Teknoloji! <br> 
                    Mükemmel olanaklar!</h1>

                <?php
                //include 'showCourse.php';
                // echo  $courseList;

                echo "Deneyin öğrenin."
                ?>

                <td valign="top" width = "40%">
                <p id="SideInfo">  Değerli ziyaretçi; <br>
                    Etkili ve kalıcı bir öğrenme için ve ezberci eğitimden kurtulmak için uygulama 
                    yapmanın ne denli bir öneme sahip olduğu tartışılamaz bir gerçektir. Ancak 
                    uygulama malzemelerini bulmak her zaman kolay olmuyor. Seher Elektronik olarak 
                    gençlerimizin eğitimlerini desteklemek için okul konularıyla ilgili deney 
                    setlerini gençlerimizin hizmetine sunuyoruz. Setlerimiz sayesinde gençlerimiz 
                    derslerinde gördükleri konuların bir bölümünü uygulama yapma imkanı bulacak, 
                    böylelikle kalıcı bir öğrenme gerçekleşecektir. Setlerimizin sizlere faydalı 
                    olması dileğiyle saygı ve sevgilerimizi sunuyoruz. <br><br>
                    "DUYARSAM UNUTURUM <br>
                    GÖRÜRSEM HATIRLARIM <br>
                    YAPARSAM ÖĞRENİRİM" </p>
            </tr>
        </table>
    </div>
    <?php include "pageFooter.html" ?>

</div>
<script src="js/modal.js"
></script>
</body>
</html>