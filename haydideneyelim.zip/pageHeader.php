<?php 

$rightMenu = '';


if(isset($_SESSION['login'] ))
{
  $rightMenu .= '<a id="username"><b>Kullanıcı: </b>'.$_SESSION['username'].'</a>';
  if($_SESSION['login'] == 1) // student
  {
    $rightMenu .=  '<a href="showStudentCourse.php">Derslerim</a>'; 
    $rightMenu .=  '<a href="selectCourse.php">Ders Ekle/Sil</a>';

  }else
  if($_SESSION['login'] == 2) // admin
  {
    $rightMenu .=  '<a href="selectStudents.php">Öğrenci Ekle/Sil</a>'; 
    $rightMenu .=  '<a href="selectCourseAdmin.php">Ders Programı Ekle/Sil</a>'; 
  }

  $rightMenu .= ' <a href="logOut.php">Çıkış</a>';
}else
{
  $rightMenu .= '<button class="loginButton" onclick="'.  "document.getElementById('id01').style.display='block'"  .'"style="width:auto;">Giriş</button>' ;

}
//                  <a href="#search">Search</a>
//                  <a href="#about">About</a>


?>
<head>
    <meta charset="utf8_turkish_ci">
<title> Haydi Deneyelim - Eğitim ve öğretimde dünya lideri! </title>
   <link rel="stylesheet" href="style/style.css" type="text/css" media="screen" />
   <link rel="stylesheet" href="style/styleFlex.css" type="text/css" media="screen" />
   <link rel="stylesheet" href="style/styleModal.css" type="text/css" media="screen" />
   <script src="js/utils.js"></script>


   <div id="pageHeader"><table width="100%" border="0" cellspacing="0" cellpadding="12">
      <tr>
        <td><a href="http://localhost/haydideneyelim"><img src="./images/header_logo.png" alt="Logo" width="200" height="45" border="0" />
      </tr>
      <tr>
        <td colspan="2" >
          <div  class="SegmentButton" >
            <div class="topnav">
                <a href="http://localhost/haydideneyelim">Anasayfa</a>
                <a href="showCourse.php">Bütün Dersler</a>
 
                <div class="topnav-right">
                <?php echo $rightMenu ?>
                </div>
              </div>
        </div>
        </td>
        </tr>
      </table>
    </div>


    
<div id="id01" class="modal">
  
  <form class="modal-content animate" method="POST" action="login.php">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/logo.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="uname"><b>Kullanıcı Adı</b></label>
      <input type="text" placeholder="Kullanıcı adı" name="uname" id="uname" required>

      <label for="psw"><b>Şifre</b></label>
      <input type="password" placeholder="Şifre" name="psw" id="psw" required>
      <button  type="submit">Giriş</button>
    </div>
    <div class="container" style="background-color:#e0e0e0">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">İptal</button>
      <span class="psw"> <a href="#"> Şifremi unuttum! (YAKINDA)</a></span>
    </div>
  </form>
</div>


<script>
    // Get the modal
    var modal = document.getElementById('id01');
    
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    </script>

</head>


